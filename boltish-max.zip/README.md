# Boltish Max

**High-end Bolt.new-Style IDE** für Codespaces/localhost:  
Monaco, 3-Pane-Layout, Command-Palette, ZIP-Import/Export, esbuild-wasm Bundling (mit bare-imports via esm.sh), Theme, Console-Bridge.

## Start

```bash
npm i
npm run dev
# http://localhost:5173
```

## Features
- Dateien/Ordner (in-memory, persist per Code anpassbar)
- Tabs, FileTree
- Monaco Editor (TS/JS/HTML/CSS/JSON/MD)
- **Run**: baut eine komplette HTML-Seite, injiziert Console-Bridge; optional **esbuild-wasm** bundelt aktiven Code (inkl. `import react` via esm.sh)
- Drag&Drop & Upload (auch ZIP), Export ZIP
- Command-Palette (⌘K / Ctrl+K)
- Dark/Light Theme
