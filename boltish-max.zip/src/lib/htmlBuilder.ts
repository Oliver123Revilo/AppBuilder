import { FileNode, walkFiles } from './fs'

export function consoleBridge(){
  return '<script>(function(){var send=function(l){var a=[].slice.call(arguments,1); parent.postMessage({type:\'console\',msg:{level:l,args:a}},\'*\')};[\'log\',\'warn\',\'error\'].forEach(function(l){var o=console[l];console[l]=function(){send.apply(null,[l].concat([].slice.call(arguments)));return o.apply(console,arguments)}});window.addEventListener(\'error\',function(e){send(\'error\',e.message+\' @\'+e.filename+\':\'+e.lineno+\':\'+e.colno)})})();</script>'
}

export function baseHtml(styles:string, scripts:string){
  return '<!doctype html><html><head><meta charset="utf-8"/>'+styles+'</head><body><div id="app"></div>'+scripts+consoleBridge()+'</body></html>'
}

export function buildHtml(tree: FileNode){
  const files = walkFiles(tree)
  const idx = files.find(f=> f.name.toLowerCase()==='index.html')
  const css = files.filter(f=>f.name.endsWith('.css')).map(f=>'<style>'+(f.content||'')+'</style>').join('\n')
  const js  = files.filter(f=>f.name.endsWith('.js')).map(f=>'<script>'+(f.content||'')+'</script>').join('\n')
  if(idx){ const html=idx.content||''; return html.replace(/<\/body>/i, consoleBridge()+'</body>') }
  return baseHtml(css, js)
}
