import { create } from 'zustand'
import JSZip from 'jszip'
import prettyBytes from 'pretty-bytes'
import { FileNode, starter, findNode, insertFile, isBinary, walkFiles, removePath } from '../lib/fs'

type Line = { level:'log'|'warn'|'error', text:string }

type State = {
  tree: FileNode
  active: string
  tabs: string[]
  console: Line[]
  info: string
  theme: 'dark'|'light'
}

type Actions = {
  open: (p:string)=>void
  close: (p:string)=>void
  setContent: (p:string, c:string)=>void
  importAny: (files: FileList | File[]) => Promise<void>
  exportZip: () => Promise<void>
  reset: ()=>void
  log: (l:Line)=>void
  clear: ()=>void
  sizeOfActive: ()=>string
  remove: (p:string)=>void
  toggleTheme: ()=>void
}

export const useProject = create<State & Actions>((set, get)=>({
  tree: starter(),
  active: 'index.html',
  tabs: ['index.html'],
  console: [],
  info: '',
  theme: 'dark',
  open: (p)=> set(s=>({ active: p, tabs: s.tabs.includes(p)? s.tabs : [...s.tabs, p] })),
  close: (p)=> set(s=>{ const i=s.tabs.indexOf(p); const next=s.tabs.filter(t=>t!==p); return { tabs: next, active: s.active===p ? (next[i-1]||next[i]||'index.html') : s.active } }),
  setContent: (p,c)=> set(s=>{ const copy=JSON.parse(JSON.stringify(s.tree)) as FileNode; const n=findNode(copy,p); if(n && n.type==='file') n.content=c; return { tree: copy } }),
  importAny: async (fileList)=>{
    const copy = JSON.parse(JSON.stringify(get().tree)) as FileNode
    const files = Array.from(fileList)
    for(const file of files){
      if(file.name.endsWith('.zip')){
        const zip = await JSZip.loadAsync(await file.arrayBuffer())
        const paths:string[]=[]; zip.forEach(p=>paths.push(p))
        for(const p of paths){ const zf=zip.file(p); if(zf) insertFile(copy, p, await zf.async('string')) }
      } else if(isBinary(file.name)){
        const arr=await file.arrayBuffer()
        const b64=btoa(String.fromCharCode(...new Uint8Array(arr)))
        const mime=file.type||'application/octet-stream'
        insertFile(copy, file.name, 'data:'+mime+';base64,'+b64)
      } else {
        insertFile(copy, file.name, await file.text())
      }
    }
    set({ tree: copy })
  },
  exportZip: async ()=>{
    const zip = new JSZip()
    walkFiles(get().tree).forEach(f=> zip.file(f.path||f.name, f.content||''))
    const blob = await zip.generateAsync({type:'blob'})
    const url = URL.createObjectURL(blob)
    const a=document.createElement('a'); a.href=url; a.download='boltish-max.zip'; a.click()
    URL.revokeObjectURL(url)
  },
  reset: ()=> set({ tree: starter(), active:'index.html', tabs:['index.html'], console:[] }),
  log: (l)=> set(s=>({ console:[...s.console, l] })),
  clear: ()=> set({ console: [] }),
  sizeOfActive: ()=>{
    const s=get()
    const n=findNode(s.tree, s.active)
    const len = n && n.type==='file' ? (n.content||'').length : 0
    return prettyBytes(len)
  },
  remove: (p)=> set(s=>{ const copy=JSON.parse(JSON.stringify(s.tree)) as FileNode; removePath(copy, p); const tabs=s.tabs.filter(t=>t!==p); const active= s.active===p ? (tabs[0] || 'index.html') : s.active; return { tree: copy, tabs, active } }),
  toggleTheme: ()=> set(s=>({ theme: s.theme==='dark'?'light':'dark' }))
}))
