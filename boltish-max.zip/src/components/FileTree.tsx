import React, { useState } from 'react'
import { FileNode } from '../lib/fs'

export default function FileTree({ root, activePath, onOpen, onDelete }:{ root: FileNode; activePath: string; onOpen: (p:string)=>void; onDelete: (p:string)=>void; }){
  return <div style={{padding:6}}>{root.children?.map(n=>(<TreeNode key={n.id} node={n} depth={0} activePath={activePath} onOpen={onOpen} onDelete={onDelete}/>))}</div>
}

function TreeNode({ node, depth, activePath, onOpen, onDelete }:{ node: FileNode; depth:number; activePath:string; onOpen:(p:string)=>void; onDelete:(p:string)=>void; }){
  const [open,setOpen]=useState(true)
  const isActive = node.type==='file' && node.path===activePath
  const pad = { paddingLeft: String(depth*12+8)+'px' } as React.CSSProperties
  return <div>
    <div className={'file-row'+(isActive?' active':'')} style={pad} onClick={()=> node.type==='file'? onOpen(node.path) : setOpen(!open)}>
      <span style={{opacity:.7, marginRight:6}}>{node.type==='folder' ? (open?'▾':'▸') : '•'}</span>
      <span style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{node.name}</span>
      {node.type==='file' && <button style={{marginLeft:'auto'}} onClick={(e)=>{e.stopPropagation(); if(confirm('Löschen?')) onDelete(node.path)}}>del</button>}
    </div>
    {node.children && open && <div>{node.children.map(c=>(<TreeNode key={c.id} node={c} depth={depth+1} activePath={activePath} onOpen={onOpen} onDelete={onDelete}/>))}</div>}
  </div>
}
