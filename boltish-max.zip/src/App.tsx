import React, { useEffect, useMemo, useRef, useState } from 'react'
import Editor from '@monaco-editor/react'
import { PanelGroup, Panel, PanelResizeHandle } from 'react-resizable-panels'
import { useDropzone } from 'react-dropzone'
import { useProject } from './state/useProject'
import { findNode } from './lib/fs'
import { buildHtml } from './lib/htmlBuilder'
import { bundle } from './lib/bundler'
import FileTree from './components/FileTree'
import CommandBar from './components/CommandBar'
import { Download, Play, Square, Upload, Wand2, FolderPlus, FilePlus2, Moon, Sun } from 'lucide-react'

export default function App(){
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const { tree, active, tabs, open, close, setContent, importAny, exportZip, reset, console, clear, log, sizeOfActive, remove, theme, toggleTheme } = useProject()
  const activeNode = useMemo(()=>findNode(tree, active),[tree,active])
  const [cmdOpen, setCmdOpen] = useState(false)
  const [bundleMode, setBundleMode] = useState<'raw'|'bundle'>('bundle')

  // console bridge handler
  useEffect(()=>{ const onMsg=(e:MessageEvent)=>{ if(e.data && e.data.type==='console'){ const level=e.data.msg.level||'log'; const args=e.data.msg.args||[]; const text=args.map((a:any)=> typeof a==='string'? a: JSON.stringify(a)).join(' '); log({level, text}) } }; window.addEventListener('message', onMsg); return ()=>window.removeEventListener('message', onMsg) },[])

  const { getRootProps, getInputProps, isDragActive, open:openPicker } = useDropzone({ onDrop: (files)=>importAny(files), noClick: true, multiple: true })
  useEffect(()=>{ const onKey=(e:KeyboardEvent)=>{ if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='k'){ e.preventDefault(); setCmdOpen(v=>!v) } }; window.addEventListener('keydown', onKey); return ()=>window.removeEventListener('keydown', onKey) },[])

  async function run(){ clear(); let html = buildHtml(tree)
    // If bundleMode, bundle active JS/TS (main.js or active file) and inject as script
    if(bundleMode==='bundle' && activeNode && activeNode.type==='file' && /\.(t|j)sx?$/.test(active)){
      const code = activeNode.content||''
      try{
        const out = await bundle(code)
        html = html.replace(/<\/body>/i, '<script>'+out+'</script></body>')
      }catch(err:any){ log({level:'error', text: String(err.message||err)}) }
    }
    const blob=new Blob([html],{type:'text/html'}); const url=URL.createObjectURL(blob); const i=iframeRef.current; if(i) i.src=url
  }
  function stop(){ const i=iframeRef.current; if(i) i.src='about:blank' }

  function onChange(v:string|undefined){ setContent(active, v||'') }

  const items = [
    { id:'open', label:'Datei öffnen…', shortcut:'⌘K', onSelect:()=>setCmdOpen(false) },
    { id:'import', label:'Import (Dateien/ZIP)', onSelect:()=>openPicker() },
    { id:'run', label:'Run (Preview)', shortcut:'⌘↵', onSelect:()=>run() },
    { id:'stop', label:'Stop Preview', onSelect:()=>stop() },
    { id:'export', label:'Export als ZIP', onSelect:()=>exportZip() },
    { id:'reset', label:'Projekt zurücksetzen', onSelect:()=>reset() },
  ]

  return <div className={'h-full w-full '+(theme==='light'?'light':'')} {...getRootProps()}>
    <input {...getInputProps()} />
    <CommandBar open={cmdOpen} onOpenChange={setCmdOpen} items={items} />
    <div className="toolbar">
      <div style={{display:'flex', alignItems:'center', gap:8}}>
        <strong>⚡ Boltish Max</strong>
        <span className="badge">Vite + Monaco + esbuild</span>
      </div>
      <button onClick={()=>openPicker()} title="Import"><Upload size={16}/> Import</button>
      <button onClick={()=>run()} title="Run"><Play size={16}/> Run</button>
      <button onClick={()=>stop()} title="Stop"><Square size={16}/> Stop</button>
      <button onClick={()=>exportZip()} title="Export ZIP"><Download size={16}/> Export</button>
      <button onClick={()=>reset()} title="Reset"><Wand2 size={16}/> Reset</button>
      <button onClick={()=>toggleTheme()} title="Theme">{theme==='dark'? <Sun size={16}/> : <Moon size={16}/>} Theme</button>
      <span className="badge" style={{marginLeft:'auto'}}>Bundle: 
        <select value={bundleMode} onChange={e=>setBundleMode(e.target.value as any)} style={{marginLeft:6}}>
          <option value="bundle">esbuild</option>
          <option value="raw">raw scripts</option>
        </select>
      </span>
      {isDragActive && <span className="badge">Drop…</span>}
    </div>

    <PanelGroup direction="horizontal" style={{height:'calc(100% - 44px)'}}>
      <Panel defaultSize={22} minSize={16}>
        <div style={{height:'100%',display:'grid',gridTemplateRows:'auto 1fr', borderRight:'1px solid var(--b)'}}>
          <div className="leftbar-head">
            <button onClick={()=>alert('New folder via Command Palette demnächst')}><FolderPlus size={16}/> Ordner</button>
            <button onClick={()=>alert('New file via Command Palette demnächst')}><FilePlus2 size={16}/> Datei</button>
          </div>
          <div style={{overflow:'auto'}}>
            <FileTree root={tree} activePath={active} onOpen={open} onDelete={remove} />
          </div>
        </div>
      </Panel>
      <PanelResizeHandle className="pane-border" style={{width:1}} />
      <Panel defaultSize={48} minSize={30}>
        <div style={{height:'100%',display:'grid',gridTemplateRows:'auto 1fr auto'}}>
          <div style={{display:'flex',gap:6,overflowX:'auto',padding:6,borderBottom:'1px solid var(--b)'}}>
            {tabs.map(p=>(
              <button key={p} className={'tab'+(p===active?' active':'')} onClick={()=>open(p)}>
                {p} <span style={{marginLeft:6,opacity:.7}} onClick={(e)=>{ e.stopPropagation(); close(p) }}>×</span>
              </button>
            ))}
          </div>
          <div>
            {activeNode && activeNode.type==='file'
              ? <Editor path={active} language={languageFor(active)} value={activeNode.content||''} onChange={onChange} theme={theme==='dark'?'vs-dark':'light'} options={{minimap:{enabled:false},fontSize:14,automaticLayout:true,scrollBeyondLastLine:false}} height="100%" />
              : <div style={{height:'100%',display:'grid',placeItems:'center',opacity:.7,fontSize:12}}>Ordner ausgewählt</div>
            }
          </div>
          <div style={{height:28,display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 8px',borderTop:'1px solid var(--b)',fontSize:12,opacity:.8}}>
            <span className="mut">{active}</span><span className="mut">{sizeOfActive()}</span>
          </div>
        </div>
      </Panel>
      <PanelResizeHandle className="pane-border" style={{width:1}} />
      <Panel minSize={20}>
        <div style={{height:'100%',display:'grid',gridTemplateRows:'auto 1fr 160px'}}>
          <div className="right-head">
            <strong>Preview</strong> <span className="mut">/ Console</span>
          </div>
          <div id="preview">
            <iframe ref={iframeRef} title="preview" sandbox="allow-scripts allow-same-origin"></iframe>
          </div>
          <Console />
        </div>
      </Panel>
    </PanelGroup>
  </div>
}

function Console(){
  const { console } = useProject()
  return <div className="console" style={{borderTop:'1px solid var(--b)'}}>
    {console.length===0? <div style={{opacity:.6}}>console.log erscheint hier…</div> : console.map((l,i)=>(<div key={i} className={l.level}>{'['+l.level+'] '} {l.text}</div>))}
  </div>
}

function languageFor(p:string){
  const s=p.toLowerCase()
  if(s.endsWith('.ts')||s.endsWith('.tsx')) return 'typescript'
  if(s.endsWith('.js')||s.endsWith('.jsx')) return 'javascript'
  if(s.endsWith('.json')) return 'json'
  if(s.endsWith('.css')) return 'css'
  if(s.endsWith('.html')) return 'html'
  if(s.endsWith('.md')) return 'markdown'
  return 'plaintext'
}
