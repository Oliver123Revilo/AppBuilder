# Boltish Max (Bolt-Style)
Vite + React + TS • Monaco • esbuild-wasm • Command Palette • ZIP Import/Export • Bolt-ähnliches UI.

## Start
```bash
npm i
npm run dev
# http://localhost:5173
```
