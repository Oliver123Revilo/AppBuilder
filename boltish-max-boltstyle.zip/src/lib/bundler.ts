import * as esbuild from 'esbuild-wasm'

let started = false
export async function initEsbuild(){
  if(started) return
  await esbuild.initialize({ wasmURL: 'https://unpkg.com/esbuild-wasm@0.19.11/esbuild.wasm' })
  started = true
}

function httpPlugin(){
  return {
    name: 'http-resolver',
    setup(build: esbuild.PluginBuild){
      build.onResolve({ filter: /^[^./].*/ }, args => ({ path: `https://esm.sh/${args.path}` }))
      build.onResolve({ filter: /^\.\// }, args => ({ path: new URL(args.path, args.importer).href }))
      build.onLoad({ filter: /.*/ }, async args => {
        const res = await fetch(args.path)
        const contents = await res.text()
        const contentType = res.headers.get('content-type') || ''
        const loader: esbuild.Loader = contentType.includes('application/json') ? 'json' : 'js'
        return { contents, loader }
      })
    }
  }
}

export async function bundle(entryCode: string){
  await initEsbuild()
  const result = await esbuild.build({
    stdin: { contents: entryCode, loader: 'ts', resolveDir: '/' },
    bundle: true,
    write: false,
    plugins: [httpPlugin()],
    format: 'iife',
    platform: 'browser',
  })
  return result.outputFiles[0].text
}
