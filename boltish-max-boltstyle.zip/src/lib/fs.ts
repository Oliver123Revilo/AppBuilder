export type NodeType = 'file'|'folder'
export type FileNode = { id:string; name:string; path:string; type:NodeType; children?:FileNode[]; content?:string }

export const uid = () => Math.random().toString(36).slice(2)+Date.now().toString(36)
export const isBinary = (name:string) => /\.(png|jpe?g|gif|svg|webp|ico|bmp)$/i.test(name)

export const join = (a:string,b:string) => a? (a.replace(/\/+$/,'')+'/'+b.replace(/^\/+/,'')) : b
const splitPath = (p:string) => { const parts=p.split('/').filter(Boolean); const file=parts.pop()||''; return {folders:parts, file} }

export function ensureTree(root:FileNode, folders:string[]){
  let cur=root
  for(const f of folders){
    let n=cur.children?.find(c=>c.type==='folder' && c.name===f)
    if(!n){ n={id:uid(), name:f, path:join(cur.path,f), type:'folder', children:[]}; (cur.children||(cur.children=[])).push(n) }
    cur=n
  }
  return cur
}

export function insertFile(root:FileNode, fullPath:string, content:string){
  const sp=splitPath(fullPath)
  const parent=ensureTree(root, sp.folders)
  const ex=parent.children?.find(c=>c.type==='file' && c.name===sp.file) as FileNode|undefined
  if(ex){ ex.content=content; return ex }
  const node:FileNode={ id:uid(), name:sp.file, path:join(parent.path,sp.file), type:'file', content }
  ;(parent.children||(parent.children=[])).push(node)
  return node
}

export function removePath(root:FileNode, path:string){
  const parts=path.split('/').filter(Boolean)
  const last=parts.pop()
  const parent = parts.length? findNode(root, parts.join('/')) : root
  if(!parent || !parent.children || !last) return false
  const idx = parent.children.findIndex(c=>c.name===last)
  if(idx>=0) parent.children.splice(idx,1)
  return idx>=0
}

export function findNode(root:FileNode, path:string):FileNode|undefined{
  if(path===''||path==='/') return root
  const parts=path.split('/').filter(Boolean)
  let cur:FileNode|undefined=root
  for(const p of parts){
    cur=cur?.children?.find(c=>c.name===p)
    if(!cur) return
  }
  return cur
}

export function walkFiles(root:FileNode){
  const out:FileNode[]=[]
  const rec=(n:FileNode)=>{ if(n.type==='file') out.push(n); n.children?.forEach(rec) }
  rec(root)
  return out
}

export function starter():FileNode{
  const root:FileNode={ id:uid(), name:'root', path:'', type:'folder', children:[] }
  insertFile(root,'index.html','<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Boltish Max</title><link rel="stylesheet" href="styles.css"/></head><body><h1>Boltish Max</h1><p>Bearbeite <code>main.js</code> und klicke <b>Run</b>.</p><pre id="out"></pre><script src="main.js"></script></body></html>')
  insertFile(root,'styles.css','body{font-family:Inter,system-ui,ui-sans-serif;margin:16px} pre{background:#0b0b0b;color:#0f0;padding:12px;border-radius:8px}')
  insertFile(root,'main.js','document.getElementById("out").textContent="Hallo "+new Date().toLocaleTimeString(); console.log("Ready")')
  insertFile(root,'README.md','# Willkommen in Boltish Max\n\n- Links: Dateien\n- Mitte: Editor\n- Rechts: Preview + Konsole\n\n**Tipp:** Du kannst ZIPs importieren.')
  return root
}
