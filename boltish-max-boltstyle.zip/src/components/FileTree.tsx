import React, { useState } from 'react'
import { FileNode } from '../lib/fs'
import { File as FileIcon, Folder as FolderIcon, FolderOpen } from 'lucide-react'

export default function FileTree({
  root, activePath, onOpen, onDelete
}:{ root: FileNode; activePath: string; onOpen: (p:string)=>void; onDelete: (p:string)=>void; }){
  return <div style={{padding:6}}>
    {root.children?.map(n=>(
      <TreeNode key={n.id} node={n} depth={0} activePath={activePath} onOpen={onOpen} onDelete={onDelete}/>
    ))}
  </div>
}

function TreeNode({
  node, depth, activePath, onOpen, onDelete
}:{ node: FileNode; depth:number; activePath:string; onOpen:(p:string)=>void; onDelete:(p:string)=>void; }){
  const [open,setOpen]=useState(true)
  const isActive = node.type==='file' && node.path===activePath
  const pad = { paddingLeft: String(depth*12+6)+'px' } as React.CSSProperties

  const icon = node.type==='folder'
    ? (open ? <FolderOpen size={16}/> : <FolderIcon size={16}/>)
    : <FileIcon size={16}/>

  return <div>
    <div className={'file-row'+(isActive?' active':'')} style={pad}
         onClick={()=> node.type==='file'? onOpen(node.path) : setOpen(!open)}>
      <span style={{opacity:.75}}>{icon}</span>
      <span className="file-label">{node.name}</span>
      {node.type==='file' && (
        <button className="btn-ghost icon-btn"
                onClick={(e)=>{e.stopPropagation(); if(confirm('Löschen?')) onDelete(node.path)}}>
          del
        </button>
      )}
    </div>
    {node.children && open && (
      <div>
        {node.children.map(c=>(
          <TreeNode key={c.id} node={c} depth={depth+1} activePath={activePath} onOpen={onOpen} onDelete={onDelete}/>
        ))}
      </div>
    )}
  </div>
}
