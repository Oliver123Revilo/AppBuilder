import * as React from 'react'
import { Command } from 'cmdk'

type Item = { id:string; label:string; shortcut?:string; onSelect:()=>void }

export default function CommandBar({ open, onOpenChange, items }:{ open:boolean; onOpenChange:(v:boolean)=>void; items:Item[] }){
  return (
    <Command.Dialog open={open} onOpenChange={onOpenChange} label="Befehlspalette">
      <div style={{padding:8, borderBottom:'1px solid var(--b)'}}>
        <Command.Input placeholder="Befehl suchen…" />
      </div>
      <Command.List style={{maxHeight:300, overflow:'auto'}}>
        <Command.Empty>Nichts gefunden…</Command.Empty>
        {items.map(it=>(
          <Command.Item key={it.id} value={it.label} onSelect={()=>{ it.onSelect(); onOpenChange(false) }}>
            {it.label}
            {it.shortcut && <span style={{marginLeft:'auto'}} className="kbd">{it.shortcut}</span>}
          </Command.Item>
        ))}
      </Command.List>
    </Command.Dialog>
  )
}
