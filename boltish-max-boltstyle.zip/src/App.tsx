import React, { useEffect, useMemo, useRef, useState } from 'react'
import Editor from '@monaco-editor/react'
import { PanelGroup, Panel, PanelResizeHandle } from 'react-resizable-panels'
import { useDropzone } from 'react-dropzone'
import { useProject } from './state/useProject'
import { findNode } from './lib/fs'
import { buildHtml } from './lib/htmlBuilder'
import { bundle } from './lib/bundler'
import FileTree from './components/FileTree'
import CommandBar from './components/CommandBar'
import { Download, Play, Square, Upload, Wand2, FolderPlus, FilePlus2, Moon, Sun } from 'lucide-react'

export default function App(){
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const { tree, active, tabs, open, close, setContent, importAny, exportZip, reset, console, clear, log, sizeOfActive, remove, theme, toggleTheme } = useProject()
  const activeNode = useMemo(()=>findNode(tree, active),[tree,active])
  const [cmdOpen, setCmdOpen] = useState(false)
  const [bundleMode, setBundleMode] = useState<'raw'|'bundle'>('bundle')

  useEffect(()=>{ const onMsg=(e:MessageEvent)=>{ if(e.data && e.data.type==='console'){ const level=e.data.msg.level||'log'; const args=e.data.msg.args||[]; const text=args.map((a:any)=> typeof a==='string'? a: JSON.stringify(a)).join(' '); log({level, text}) } }; window.addEventListener('message', onMsg); return ()=>window.removeEventListener('message', onMsg) },[])

  useEffect(()=>{
    const onKey=(e:KeyboardEvent)=>{
      const cmd = e.metaKey || e.ctrlKey
      if(cmd && e.key.toLowerCase()==='k'){ e.preventDefault(); setCmdOpen(v=>!v) }
      if(cmd && (e.key==='Enter')){ e.preventDefault(); run() }
    }
    window.addEventListener('keydown', onKey)
    return ()=>window.removeEventListener('keydown', onKey)
  },[tree,active,bundleMode])

  const { getRootProps, getInputProps, isDragActive, open:openPicker } =
    useDropzone({ onDrop: (files)=>importAny(files), noClick: true, multiple: true })

  async function run(){
    clear()
    let html = buildHtml(tree)
    if(bundleMode==='bundle' && activeNode && activeNode.type==='file' && /(t|j)sx?$/.test(active)){
      try{
        const out = await bundle(activeNode.content||'')
        html = html.replace(/<\/body>/i, '<script>'+out+'</script></body>')
      }catch(err:any){ log({level:'error', text: String(err.message||err)}) }
    }
    const blob=new Blob([html],{type:'text/html'})
    const url=URL.createObjectURL(blob)
    const i=iframeRef.current; if(i) i.src=url
  }
  function stop(){ const i=iframeRef.current; if(i) i.src='about:blank' }
  function onChange(v:string|undefined){ setContent(active, v||'') }

  const items = [
    { id:'import', label:'Import (Dateien/ZIP)', onSelect:()=>openPicker(), shortcut:'⌘I' },
    { id:'run', label:'Run (Preview)', onSelect:()=>run(), shortcut:'⌘↵' },
    { id:'stop', label:'Stop Preview', onSelect:()=>stop() },
    { id:'export', label:'Export als ZIP', onSelect:()=>exportZip() },
    { id:'reset', label:'Projekt zurücksetzen', onSelect:()=>reset() },
  ]

  return <div className={'h-full w-full '+(theme==='light'?'light':'')} {...getRootProps()}>
    <input {...getInputProps()} />
    <CommandBar open={cmdOpen} onOpenChange={setCmdOpen} items={items} />

    <div className="toolbar">
      <div style={{display:'flex', alignItems:'center', gap:10}}>
        <strong className="brand">⚡ Boltish Max</strong>
        <span className="badge">Vite • Monaco • esbuild</span>
      </div>
      <button className="btn" onClick={()=>openPicker()} title="Import"><Upload size={16}/> Import</button>
      <button className="btn" onClick={()=>run()} title="Run"><Play size={16}/> Run <span className="kbd">⌘⏎</span></button>
      <button className="btn" onClick={()=>stop()} title="Stop"><Square size={16}/> Stop</button>
      <button className="btn" onClick={()=>exportZip()} title="Export"><Download size={16}/> Export</button>
      <button className="btn-ghost" onClick={()=>reset()} title="Reset"><Wand2 size={16}/> Reset</button>
      <button className="btn-ghost icon-btn" onClick={()=>toggleTheme()} title="Theme">
        {theme==='dark'? <Sun size={16}/> : <Moon size={16}/>}
      </button>
      <span className="badge" style={{marginLeft:'auto'}}>
        Bundle:
        <select value={bundleMode} onChange={e=>setBundleMode(e.target.value as any)} style={{marginLeft:6, background:'transparent', color:'inherit', border:'1px solid var(--b)', borderRadius:8, height:28}}>
          <option value="bundle">esbuild</option>
          <option value="raw">raw</option>
        </select>
      </span>
      {isDragActive && <span className="badge">Drop…</span>}
    </div>

    <PanelGroup direction="horizontal" style={{height:'calc(100% - 48px)'}}>
      <Panel defaultSize={22} minSize={16}>
        <div style={{height:'100%',display:'grid',gridTemplateRows:'auto 1fr', borderRight:'1px solid var(--b)'}}>
          <div className="leftbar-head">
            <button className="btn-ghost" onClick={()=>alert('Neuer Ordner – über Palette')}> <FolderPlus size={16}/> Ordner</button>
            <button className="btn-ghost" onClick={()=>alert('Neue Datei – über Palette')}> <FilePlus2 size={16}/> Datei</button>
          </div>
          <div style={{overflow:'auto'}}>
            <FileTree root={tree} activePath={active} onOpen={open} onDelete={remove} />
          </div>
        </div>
      </Panel>
      <PanelResizeHandle className="gutter" />
      <Panel defaultSize={48} minSize={30}>
        <div style={{height:'100%',display:'grid',gridTemplateRows:'auto 1fr auto'}}>
          <div className="tabs">
            {tabs.map(p=>(
              <button key={p} className={'tab'+(p===active?' active':'')} onClick={()=>open(p)}>
                {p} <span style={{marginLeft:6,opacity:.7}} onClick={(e)=>{ e.stopPropagation(); close(p) }}>×</span>
              </button>
            ))}
          </div>
          <div>
            {activeNode && activeNode.type==='file'
              ? <Editor
                  path={active}
                  language={languageFor(active)}
                  value={activeNode.content||''}
                  onChange={onChange}
                  theme={theme==='dark'?'vs-dark':'light'}
                  options={{minimap:{enabled:false},fontSize:14,automaticLayout:true,scrollBeyondLastLine:false}}
                  height="100%"
                />
              : <div style={{height:'100%',display:'grid',placeItems:'center',opacity:.7,fontSize:12}}>Ordner ausgewählt</div>
            }
          </div>
          <div className="status">
            <span className="mut">{active}</span>
            <span className="mut">{sizeOfActive()}</span>
          </div>
        </div>
      </Panel>
      <PanelResizeHandle className="gutter" />
      <Panel minSize={20}>
        <div style={{height:'100%',display:'grid',gridTemplateRows:'auto 1fr 160px'}}>
          <div className="right-head"><strong>Preview</strong> <span className="mut">/ Console</span></div>
          <div id="preview"><iframe ref={iframeRef} title="preview" sandbox="allow-scripts allow-same-origin"></iframe></div>
          <Console />
        </div>
      </Panel>
    </PanelGroup>
  </div>
}

function Console(){
  const { console } = useProject()
  return <div className="console">
    {console.length===0? <div style={{opacity:.6}}>console.log erscheint hier…</div>
      : console.map((l,i)=>(<div key={i} className={l.level}>{'['+l.level+'] '} {l.text}</div>))}
  </div>
}

function languageFor(p:string){
  const s=p.toLowerCase()
  if(s.endsWith('.ts')||s.endsWith('.tsx')) return 'typescript'
  if(s.endsWith('.js')||s.endsWith('.jsx')) return 'javascript'
  if(s.endsWith('.json')) return 'json'
  if(s.endsWith('.css')) return 'css'
  if(s.endsWith('.html')) return 'html'
  if(s.endsWith('.md')) return 'markdown'
  return 'plaintext'
}
